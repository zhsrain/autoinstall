
files_c=[
 'C/Threads.c',
]

files_cpp=[
 'CPP/7zip/UI/P7ZIP/wxP7ZIP.cpp',
 'CPP/Common/IntToString.cpp',
 'CPP/Common/MyString.cpp',
 'CPP/Common/MyVector.cpp',
 'CPP/Common/StringConvert.cpp',
 'CPP/Windows/FileDir.cpp',
 'CPP/Windows/FileFind.cpp',
 'CPP/Windows/FileIO.cpp',
 'CPP/Windows/FileName.cpp',
 'CPP/Common/MyWindows.cpp',
 'CPP/myWindows/wine_date_and_time.cpp',
]

